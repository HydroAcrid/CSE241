# HW 4 - JDBC and a bit of SQL
## Kevin Dotel: ked225Dotel

# How to run my program through bash 
1. Run the bash file - it is called 'run.sh' so what you would run is: 'sh run.sh'
2. Input your user ID and password once the program starts.
3. Profit 

# How to run my program the way the directions want it 
1. Run 'java -jar Capacity.jar'
2. Profit 
